// import the model
const Restaurant = require('../Models/Restaurants');


// export the controller functionalities

exports.getAllRestaurantsByLocation = (req, res) => {
    const cityName = req.params.cityName;
    Restaurant.find({
        city: cityName
    }).then(result => {
        res.status(200).json({
            message: `Restaurants fetched for city ${cityName}`,
            restaurants: result
        });
    }).catch(error => {
        res.status(500).json({
            message: 'Error in Database',
            error: error
        });
    });
}

exports.getRestaurantById = (req, res) => {
    const restId = req.params.restId;
    Restaurant.find({
        _id: restId
    }).then(result => {
        console.log(result.data);
        res.status(200).json({
            message: `Restaurants fetched for id : ${restId}`,
            restaurant: result[0]
        });
    }).catch(error => {
        res.status(500).json({
            message: 'Error in Database',
            error: error
        });
    });
}

exports.filterRestaurans = (req, res) => {
    page = page ? page : 1; // default page no. = 1
    sort = sort ? sort : 1; // 1 is ascending -1 is descending
    const itemsPerPage = 2;
    let startIndex = itemsPerPage * page - itemsPerPage; 
    let endIndex = itemsPerPage * page;
    // logic to filter the Restaurant data

    const { 
        location, 
        mealtype, 
        cuisine, 
        lcost, 
        hcost, 
        sort, 
        page = 1
    } = req.body;

    let filters = {};

    // add logic to apply filters

    if (mealtype) {
        filters["type.mealtype"] = mealtype; 
    }
    if (mealtype && cuisine) {
        filters["type.mealtype"] = mealtype;
        filters["Cuisine.cuisine"] = { $in : cuisine };
    }
    if (mealtype && hcost && lcost) {
        filters["type.mealtype"] = mealtype;
        filters["cost"] = { $lte: hcost, $gte: lcost };
    }
    if (mealtype && cuisine && lcost && hcost) {
        filters["type.mealtype"] = mealtype;
        filters["cost"] = { $lte: hcost, $gte: lcost };
        filters["Cuisine.cuisine"] = { $in : cuisine };
    }
    if (mealtype && location) {
        filters["type.mealtype"] = mealtype;
        filters["locality"] = location;
    }
    if (mealtype && location && cuisine) {
        filters["type.mealtype"] = mealtype;
        filters["locality"] = location;
        filters["Cuisine.cuisine"] = { $in : cuisine };
    }
    if (mealtype && location && lcost && hcost) {
        filters["type.mealtype"] = mealtype;
        filters["locality"] = location;
        filters["cost"] = { $lte: hcost, $gte: lcost };
    }
    if (mealtype && location && cuisine && lcost && hcost) {
        filters["type.mealtype"] = mealtype;
        filters["locality"] = location;
        filters["Cuisine.cuisine"] = { $in : cuisine };
        filters["cost"] = { $lte: hcost, $gte: lcost };
    }
    console.log(filters);
    
    Restaurant.find(filters).sort({ min_price: sort }).then(result => {

        const pageSize = 2;
        let tempArray = [];

        function paginate(arr, page_size, page_no) {
           let paginatedResult = [];
           paginatedResult = arr.slice(startIndex,endIndex)
           return paginatedResult;
        }

        tempArray = paginate(result, pageSize, page);

        res.status(200).json({
            message: `Filtered Restaurants fetched`,
            restaurants: tempArray,
            totalResultsCount: result.length,
            pageNo: page,
            pageSize: pageSize
        });

    }).catch(error => {
        res.status(500).json({
            message: 'Error in Database',
            error: error
        });
    })
}

exports.getAllRestaurantsByMealType = (req, res) => {
    console.log(req);
    const mealtypeid= req.params.mealType;
    Restaurant.find({
        mealtype_id: mealtypeid
    }).then((result) => {
        res.status(200).json({
            message: `Restaurants fetched for mealtype id ${mealtypeid}`,
            restaurants: result
        });
    }).catch(error => {
        res.status(500).json({
            message: 'Error in Database',
            error: error
        });
    });
}